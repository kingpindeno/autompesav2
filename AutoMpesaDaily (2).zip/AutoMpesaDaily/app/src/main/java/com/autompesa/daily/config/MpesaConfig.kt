package com.autompesa.daily.config

/**
 * ⚠️ SECURITY WARNING ⚠️
 * This file contains sensitive information.
 * PIN is stored in plain text - ONLY use on trusted devices.
 */
object MpesaConfig {
    // ========== USER CONFIGURATION ==========
    // EDIT THESE VALUES BEFORE BUILDING APK

    // Recipient phone number (without country code)
    const val RECIPIENT_PHONE = "0712345678"

    // Amount to send in KES
    const val AMOUNT = "1000"

    // ⚠️ M-Pesa PIN (STORED IN PLAIN TEXT)
    const val MPESA_PIN = "1234"

    // Schedule time (24-hour format)
    const val SCHEDULE_HOUR = 6    // 6 AM
    const val SCHEDULE_MINUTE = 0  // 0 minutes

    // ========== SYSTEM CONFIGURATION ==========
    // Do not change these unless necessary

    // USSD Codes
    const val USSD_CODE = "*334#"       // Kenya M-Pesa menu
    const val COUNTRY_CODE = "+254"     // Kenya (+255 for Tanzania)

    // Transaction Settings
    const val MAX_RETRIES = 3
    const val RETRY_DELAY_MINUTES = 15L

    // Notification IDs
    const val NOTIFICATION_ID_TRANSACTION = 1001
    const val NOTIFICATION_ID_STATUS = 1002
    const val NOTIFICATION_CHANNEL_ID = "mpesa_transactions"

    // SharedPreferences Keys
    const val PREFS_NAME = "AutoMpesaPrefs"
    const val KEY_LAST_SENT = "last_sent_time"
    const val KEY_IS_ENABLED = "service_enabled"
    const val KEY_TOTAL_SENT = "total_amount_sent"

    /**
     * Get full USSD string for direct dialing (if supported)
     * Format: *334*1*[phone]*[amount]*[PIN]#
     */
    fun getDirectUssdString(): String {
        return "*334*1*$RECIPIENT_PHONE*$AMOUNT*$MPESA_PIN#"
    }

    /**
     * Get recipient with country code
     */
    fun getFullRecipientNumber(): String {
        return COUNTRY_CODE + RECIPIENT_PHONE.substring(1)
    }
}