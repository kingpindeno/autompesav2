package com.autompesa.daily.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import com.autompesa.daily.R
import com.autompesa.daily.config.MpesaConfig

/**
 * Handles all notifications for the app
 */
class NotificationService(private val context: Context) {

    private val notificationManager by lazy {
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    init {
        createNotificationChannel()
    }

    fun showStatusNotification(message: String) {
        val notification = NotificationCompat.Builder(context, MpesaConfig.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("AutoMpesa Daily")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        notificationManager.notify(MpesaConfig.NOTIFICATION_ID_STATUS, notification)
    }

    fun showTransactionNotification(message: String) {
        val notification = NotificationCompat.Builder(context, MpesaConfig.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("M-Pesa Transaction")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(MpesaConfig.NOTIFICATION_ID_TRANSACTION, notification)
    }

    fun showSuccessNotification(message: String) {
        val notification = NotificationCompat.Builder(context, MpesaConfig.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("✅ Transaction Successful")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(MpesaConfig.NOTIFICATION_ID_TRANSACTION + 1, notification)
    }

    fun showErrorNotification(message: String) {
        val notification = NotificationCompat.Builder(context, MpesaConfig.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("❌ Transaction Failed")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(MpesaConfig.NOTIFICATION_ID_TRANSACTION + 2, notification)
    }

    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                MpesaConfig.NOTIFICATION_CHANNEL_ID,
                "M-Pesa Transactions",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows M-Pesa transaction status"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(channel)
        }
    }
}