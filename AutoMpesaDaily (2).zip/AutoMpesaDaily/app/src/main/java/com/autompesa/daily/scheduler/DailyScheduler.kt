package com.autompesa.daily.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.work.*
import com.autompesa.daily.config.MpesaConfig
import com.autompesa.daily.work.MpesaWorker
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Handles scheduling of daily transactions
 */
class DailyScheduler(private val context: Context) {

    companion object {
        private const val TAG = "DailyScheduler"
    }

    fun scheduleDailyTransaction() {
        // Method 1: AlarmManager (precise timing)
        scheduleWithAlarmManager()

        // Method 2: WorkManager (reliable, battery-optimized)
        scheduleWithWorkManager()

        Log.d(TAG, "Daily transaction scheduled for ${MpesaConfig.SCHEDULE_HOUR}:${MpesaConfig.SCHEDULE_MINUTE}")
    }

    private fun scheduleWithAlarmManager() {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TransactionReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerTime = calculateNextTriggerTime()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        } else {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        }
    }

    private fun scheduleWithWorkManager() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .setRequiresBatteryNotLow(true)
            .build()

        val initialDelay = calculateInitialDelayMillis()

        val periodicWork = PeriodicWorkRequestBuilder<MpesaWorker>(
            1, TimeUnit.DAYS  // Repeat daily
        ).setConstraints(constraints)
            .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
            .addTag("mpesa_daily")
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "mpesa_daily_work",
            ExistingPeriodicWorkPolicy.KEEP,
            periodicWork
        )
    }

    private fun calculateNextTriggerTime(): Long {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, MpesaConfig.SCHEDULE_HOUR)
            set(Calendar.MINUTE, MpesaConfig.SCHEDULE_MINUTE)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            // If time has already passed today, schedule for tomorrow
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }
        return calendar.timeInMillis
    }

    private fun calculateInitialDelayMillis(): Long {
        val triggerTime = calculateNextTriggerTime()
        return triggerTime - System.currentTimeMillis()
    }

    fun cancelSchedule() {
        // Cancel AlarmManager
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TransactionReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)

        // Cancel WorkManager
        WorkManager.getInstance(context).cancelUniqueWork("mpesa_daily_work")

        Log.d(TAG, "Daily schedule cancelled")
    }
}