package com.autompesa.daily.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.autompesa.daily.service.MpesaTransactionService
import kotlinx.coroutines.delay

/**
 * WorkManager worker for M-Pesa transactions
 */
class MpesaWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "MpesaWorker"
    }

    override suspend fun doWork(): Result {
        Log.d(TAG, "WorkManager starting transaction")

        return try {
            // Start transaction service
            MpesaTransactionService.start(applicationContext)

            // Wait a bit to ensure service started
            delay(5000)

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Work failed", e)
            Result.retry()
        }
    }
}