package com.autompesa.daily.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.autompesa.daily.utils.PreferenceHelper

/**
 * Restarts schedule when device reboots
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_REBOOT,
            "android.intent.action.QUICKBOOT_POWERON" -> {
                Log.d(TAG, "Device rebooted - rescheduling transactions")

                // Use PreferenceHelper to check if service was enabled
                val prefs = PreferenceHelper(context)
                if (prefs.isServiceEnabled()) {
                    DailyScheduler(context).scheduleDailyTransaction()
                    Log.d(TAG, "Schedule restored after reboot")
                } else {
                    Log.d(TAG, "Service not enabled, skipping reschedule")
                }
            }
        }
    }
}