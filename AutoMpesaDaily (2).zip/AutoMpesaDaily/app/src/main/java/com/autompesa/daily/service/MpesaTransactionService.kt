package com.autompesa.daily.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.autompesa.daily.MainActivity
import com.autompesa.daily.R
import com.autompesa.daily.config.MpesaConfig
import java.util.*

/**
 * Foreground service to execute M-Pesa transaction
 */
class MpesaTransactionService : Service() {

    companion object {
        private const val TAG = "TransactionService"
        const val ACTION_START_TRANSACTION = "START_TRANSACTION"

        fun start(context: Context) {
            val intent = Intent(context, MpesaTransactionService::class.java).apply {
                action = ACTION_START_TRANSACTION
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_TRANSACTION -> {
                startForegroundService()
                executeTransaction()
            }
        }
        return START_STICKY
    }

    private fun startForegroundService() {
        createNotificationChannel()

        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, MpesaConfig.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("AutoMpesa Transaction")
            .setContentText("Processing payment...")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .build()

        startForeground(MpesaConfig.NOTIFICATION_ID_TRANSACTION, notification)
    }

    private fun executeTransaction() {
        Log.d(TAG, "Starting M-Pesa transaction")

        try {
            // Method 1: Direct USSD (faster)
            val directUssd = MpesaConfig.getDirectUssdString()
            val encodedUssd = Uri.encode(directUssd)

            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$encodedUssd")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            startActivity(intent)
            Log.d(TAG, "USSD dialed: $directUssd")

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start transaction", e)

            // Method 2: Fallback to step-by-step
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:${Uri.encode(MpesaConfig.USSD_CODE)}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            startActivity(intent)
        }

        // Stop service after transaction is initiated
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                MpesaConfig.NOTIFICATION_CHANNEL_ID,
                "M-Pesa Transactions",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows M-Pesa transaction status"
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}