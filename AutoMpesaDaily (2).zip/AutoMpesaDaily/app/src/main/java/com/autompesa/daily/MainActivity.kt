package com.autompesa.daily

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.autompesa.daily.config.MpesaConfig
import com.autompesa.daily.databinding.ActivityMainBinding
import com.autompesa.daily.scheduler.DailyScheduler
import com.autompesa.daily.utils.PermissionHelper
import com.autompesa.daily.utils.PreferenceHelper
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var permissionHelper: PermissionHelper
    private lateinit var scheduler: DailyScheduler
    private lateinit var preferenceHelper: PreferenceHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize helpers
        permissionHelper = PermissionHelper(this)
        scheduler = DailyScheduler(this)
        preferenceHelper = PreferenceHelper(this)

        showSecurityWarning()
        setupUI()
        checkPermissions()
        loadCurrentStatus()
    }

    private fun showSecurityWarning() {
        // Only show warning once
        if (!preferenceHelper.getBoolean("warning_shown", false)) {
            AlertDialog.Builder(this)
                .setTitle("⚠️ SECURITY WARNING ⚠️")
                .setMessage("""
                    1. Your M-Pesa PIN is stored in this app's code
                    2. Anyone with access to your phone can extract it
                    3. Only use on a TRUSTED, SECURE device
                    4. Do NOT share this APK with anyone
                    5. Change your M-Pesa PIN if phone is lost
                    
                    By continuing, you accept all security risks.
                """.trimIndent())
                .setPositiveButton("I Understand") { dialog, _ ->
                    preferenceHelper.saveBoolean("warning_shown", true)
                    dialog.dismiss()
                }
                .setNegativeButton("Exit") { _, _ ->
                    finish()
                }
                .setCancelable(false)
                .show()
        }
    }

    private fun setupUI() {
        binding.apply {
            // Display configured values
            tvRecipient.text = "To: ${MpesaConfig.RECIPIENT_PHONE}"
            tvAmount.text = "Amount: KES ${MpesaConfig.AMOUNT}"
            tvSchedule.text = "Time: ${MpesaConfig.SCHEDULE_HOUR}:${MpesaConfig.SCHEDULE_MINUTE.toString().padStart(2, '0')}"

            // Setup button
            btnSetup.setOnClickListener {
                setupAutomation()
            }

            // Test button (send now)
            btnTest.setOnClickListener {
                testTransaction()
            }

            // Open settings button
            btnSettings.setOnClickListener {
                openAccessibilitySettings()
            }

            // Stop button
            btnStop.setOnClickListener {
                stopAutomation()
            }

            // Status button
            btnStatus.setOnClickListener {
                showStatusDetails()
            }
        }
    }

    private fun loadCurrentStatus() {
        val isEnabled = preferenceHelper.getBoolean(MpesaConfig.KEY_IS_ENABLED, false)
        val lastSent = preferenceHelper.getLong(MpesaConfig.KEY_LAST_SENT, 0)
        val totalSent = preferenceHelper.getInt(MpesaConfig.KEY_TOTAL_SENT, 0)

        binding.tvStatus.text = if (isEnabled) {
            val nextTime = calculateNextTriggerTime()
            val formatter = SimpleDateFormat("h:mm a", Locale.getDefault())
            "✅ Active - Next: ${formatter.format(Date(nextTime))}"
        } else {
            "❌ Not active"
        }

        // Update totals if available
        if (totalSent > 0) {
            binding.tvTotal.text = "Total sent: KES $totalSent"
        }

        if (lastSent > 0) {
            val formatter = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
            binding.tvLastSent.text = "Last sent: ${formatter.format(Date(lastSent))}"
        }
    }

    private fun checkPermissions() {
        if (!permissionHelper.hasCallPermission()) {
            permissionHelper.requestCallPermission()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!permissionHelper.hasExactAlarmPermission()) {
                permissionHelper.requestExactAlarmPermission()
            }
        }
    }

    private fun setupAutomation() {
        // 1. Check accessibility service
        if (!isAccessibilityServiceEnabled()) {
            openAccessibilitySettings()
            return
        }

        // 2. Schedule daily transaction
        scheduler.scheduleDailyTransaction()

        // 3. Save enabled status and update UI
        setServiceEnabled(true)

        // 4. Show confirmation toast
        val timeStr = "${MpesaConfig.SCHEDULE_HOUR}:${MpesaConfig.SCHEDULE_MINUTE.toString().padStart(2, '0')}"
        Toast.makeText(this, "Auto-send scheduled for $timeStr daily", Toast.LENGTH_LONG).show()

        // 5. Update UI
        loadCurrentStatus()
    }

    private fun testTransaction() {
        AlertDialog.Builder(this)
            .setTitle("Test Transaction")
            .setMessage("Send KES ${MpesaConfig.AMOUNT} to ${MpesaConfig.RECIPIENT_PHONE} now?")
            .setPositiveButton("Send") { _, _ ->
                startTransactionNow()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startTransactionNow() {
        try {
            // Method 1: Direct USSD (faster)
            val directUssd = MpesaConfig.getDirectUssdString()
            val encodedUssd = Uri.encode(directUssd)

            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$encodedUssd"))
            startActivity(intent)

            // Save test transaction time
            preferenceHelper.saveLong("last_test_time", System.currentTimeMillis())

            Toast.makeText(this, "Transaction started", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            permissionHelper.requestCallPermission()
            Toast.makeText(this, "Need phone call permission", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopAutomation() {
        AlertDialog.Builder(this)
            .setTitle("Stop Auto-Send")
            .setMessage("Stop sending money automatically at ${MpesaConfig.SCHEDULE_HOUR}:${MpesaConfig.SCHEDULE_MINUTE.toString().padStart(2, '0')}?")
            .setPositiveButton("Stop") { _, _ ->
                scheduler.cancelSchedule()
                setServiceEnabled(false)

                Toast.makeText(this, "Auto-send stopped", Toast.LENGTH_LONG).show()
                loadCurrentStatus()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showStatusDetails() {
        val isEnabled = preferenceHelper.getBoolean(MpesaConfig.KEY_IS_ENABLED, false)
        val lastSent = preferenceHelper.getLong(MpesaConfig.KEY_LAST_SENT, 0)
        val totalSent = preferenceHelper.getInt(MpesaConfig.KEY_TOTAL_SENT, 0)

        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val lastSentStr = if (lastSent > 0) formatter.format(Date(lastSent)) else "Never"

        val message = """
            Status: ${if (isEnabled) "✅ ACTIVE" else "❌ INACTIVE"}
            
            Configuration:
            • Recipient: ${MpesaConfig.RECIPIENT_PHONE}
            • Amount: KES ${MpesaConfig.AMOUNT}
            • Time: ${MpesaConfig.SCHEDULE_HOUR}:${MpesaConfig.SCHEDULE_MINUTE.toString().padStart(2, '0')}
            
            History:
            • Last sent: $lastSentStr
            • Total sent: KES $totalSent
            
            Next send: ${if (isEnabled) calculateNextTriggerTimeFormatted() else "Not scheduled"}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("AutoMpesa Status")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val serviceName = "$packageName/.service.AutoMpesaAccessibilityService"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        return enabledServices?.contains(serviceName) == true
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "Please enable 'AutoMpesa Daily' service", Toast.LENGTH_LONG).show()
    }

    private fun setServiceEnabled(enabled: Boolean) {
        preferenceHelper.saveBoolean(MpesaConfig.KEY_IS_ENABLED, enabled)

        if (enabled) {
            // Save setup time
            preferenceHelper.saveLong("setup_time", System.currentTimeMillis())
        } else {
            // Clear schedule
            scheduler.cancelSchedule()
        }
    }

    private fun calculateNextTriggerTime(): Long {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, MpesaConfig.SCHEDULE_HOUR)
            set(Calendar.MINUTE, MpesaConfig.SCHEDULE_MINUTE)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            // If time has already passed today, schedule for tomorrow
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }
        return calendar.timeInMillis
    }

    private fun calculateNextTriggerTimeFormatted(): String {
        val nextTime = calculateNextTriggerTime()
        val formatter = SimpleDateFormat("EEE, MMM d, h:mm a", Locale.getDefault())
        return formatter.format(Date(nextTime))
    }

    fun recordSuccessfulTransaction(amount: Int) {
        // Update last sent time
        preferenceHelper.saveLong(MpesaConfig.KEY_LAST_SENT, System.currentTimeMillis())

        // Update total sent
        val currentTotal = preferenceHelper.getInt(MpesaConfig.KEY_TOTAL_SENT, 0)
        preferenceHelper.saveInt(MpesaConfig.KEY_TOTAL_SENT, currentTotal + amount)

        // Update UI if activity is active
        runOnUiThread {
            loadCurrentStatus()
        }
    }

    fun recordTransactionFailure(error: String) {
        // Save error log
        val errorLog = preferenceHelper.getString("error_log", "") +
                "\n${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}: $error"
        preferenceHelper.saveString("error_log", errorLog)

        // Show error toast
        runOnUiThread {
            Toast.makeText(this, "Transaction failed: $error", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permissionHelper.handlePermissionResult(requestCode, grantResults)
    }

    override fun onResume() {
        super.onResume()
        // Refresh status when activity resumes
        loadCurrentStatus()
    }
}