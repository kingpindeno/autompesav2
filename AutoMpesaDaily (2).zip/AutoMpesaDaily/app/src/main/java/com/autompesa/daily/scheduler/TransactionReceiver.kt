package com.autompesa.daily.scheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.autompesa.daily.service.MpesaTransactionService

/**
 * Receives alarm broadcasts and starts transaction service
 */
class TransactionReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "TransactionReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "Alarm triggered - starting transaction")

        // Start the transaction service
        MpesaTransactionService.start(context)

        // Reschedule for next day
        DailyScheduler(context).scheduleDailyTransaction()
    }
}