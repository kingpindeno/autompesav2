package com.autompesa.daily.utils

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Helper for USSD operations
 */
object UssdHelper {

    /**
     * Dial a USSD code
     */
    fun dialUssd(context: Context, ussdCode: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:${Uri.encode(ussdCode)}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Format USSD code for direct dial (if supported by carrier)
     * Format: *334*1*[phone]*[amount]*[PIN]#
     */
    fun formatDirectUssd(phone: String, amount: String, pin: String): String {
        return "*334*1*$phone*$amount*$pin#"
    }

    /**
     * Check if USSD might be supported (basic validation)
     */
    fun isValidUssd(ussd: String): Boolean {
        return ussd.startsWith("*") && ussd.endsWith("#")
    }
}