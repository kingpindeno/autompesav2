package com.autompesa.daily.utils

import android.content.Context
import android.content.SharedPreferences
import com.autompesa.daily.config.MpesaConfig

/**
 * Simple SharedPreferences helper
 */
class PreferenceHelper(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        MpesaConfig.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    // Save any boolean value
    fun saveBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    // Get any boolean value
    fun getBoolean(key: String, defaultValue: Boolean = false): Boolean {
        return prefs.getBoolean(key, defaultValue)
    }

    // Save any string value
    fun saveString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    // Get any string value
    fun getString(key: String, defaultValue: String = ""): String {
        return prefs.getString(key, defaultValue) ?: defaultValue
    }

    // Save any long value
    fun saveLong(key: String, value: Long) {
        prefs.edit().putLong(key, value).apply()
    }

    // Get any long value
    fun getLong(key: String, defaultValue: Long = 0): Long {
        return prefs.getLong(key, defaultValue)
    }

    // Save any int value
    fun saveInt(key: String, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }

    // Get any int value
    fun getInt(key: String, defaultValue: Int = 0): Int {
        return prefs.getInt(key, defaultValue)
    }

    // Clear all preferences (for testing)
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}