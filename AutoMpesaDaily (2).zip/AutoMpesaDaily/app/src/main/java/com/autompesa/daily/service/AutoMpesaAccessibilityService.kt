package com.autompesa.daily.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.autompesa.daily.config.MpesaConfig
import com.autompesa.daily.utils.NotificationService

/**
 * Accessibility Service that automates USSD navigation
 */
class AutoMpesaAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoMpesaService"
    }

    private val notificationService by lazy { NotificationService(this) }
    private var currentStep = 0
    private var isProcessing = false

    override fun onServiceConnected() {
        Log.d(TAG, "Accessibility service connected")
        notificationService.showStatusNotification("AutoMpesa service active")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!shouldHandleEvent(event) || isProcessing) return

        val rootNode = rootInActiveWindow ?: return
        val screenText = getScreenText(event).toLowerCase()

        Log.d(TAG, "Screen: $screenText")
        Log.d(TAG, "Current step: $currentStep")

        when (currentStep) {
            0 -> handleMenuScreen(screenText, rootNode)
            1 -> handleSendMoneyScreen(screenText, rootNode)
            2 -> handlePhoneNumberScreen(screenText, rootNode)
            3 -> handleAmountScreen(screenText, rootNode)
            4 -> handlePinScreen(screenText, rootNode)
            5 -> handleConfirmationScreen(screenText, rootNode)
            6 -> handleFinalScreen(screenText, rootNode)
        }
    }

    private fun handleMenuScreen(screenText: String, root: AccessibilityNodeInfo) {
        if (screenText.contains("send money") || screenText.contains("1. send")) {
            performTap("1", root)
            currentStep = 1
            notificationService.showTransactionNotification("Selecting: Send Money")
        }
    }

    private fun handleSendMoneyScreen(screenText: String, root: AccessibilityNodeInfo) {
        if (screenText.contains("to m-pesa") || screenText.contains("1. to m-pesa")) {
            performTap("1", root)
            currentStep = 2
            notificationService.showTransactionNotification("Selecting: To M-Pesa User")
        }
    }

    private fun handlePhoneNumberScreen(screenText: String, root: AccessibilityNodeInfo) {
        if (screenText.contains("enter number") || screenText.contains("phone number")) {
            inputText(MpesaConfig.RECIPIENT_PHONE, root)
            currentStep = 3
            notificationService.showTransactionNotification("Entering recipient: ${MpesaConfig.RECIPIENT_PHONE}")
        }
    }

    private fun handleAmountScreen(screenText: String, root: AccessibilityNodeInfo) {
        if (screenText.contains("enter amount") || screenText.contains("amount")) {
            inputText(MpesaConfig.AMOUNT, root)
            currentStep = 4
            notificationService.showTransactionNotification("Entering amount: KES ${MpesaConfig.AMOUNT}")
        }
    }

    private fun handlePinScreen(screenText: String, root: AccessibilityNodeInfo) {
        if (screenText.contains("enter pin") || screenText.contains("pin")) {
            inputText(MpesaConfig.MPESA_PIN, root)
            currentStep = 5
            notificationService.showTransactionNotification("Entering PIN")
        }
    }

    private fun handleConfirmationScreen(screenText: String, root: AccessibilityNodeInfo) {
        if (screenText.contains("confirm") || screenText.contains("1. ok")) {
            performTap("1", root)
            currentStep = 6
            notificationService.showTransactionNotification("Confirming transaction...")
        }
    }

    private fun handleFinalScreen(screenText: String, root: AccessibilityNodeInfo) {
        if (screenText.contains("success") || screenText.contains("sent") ||
            screenText.contains("completed")) {
            notificationService.showSuccessNotification(
                "KES ${MpesaConfig.AMOUNT} sent to ${MpesaConfig.RECIPIENT_PHONE}"
            )
            resetState()
        } else if (screenText.contains("fail") || screenText.contains("error")) {
            notificationService.showErrorNotification("Transaction failed")
            resetState()
        } else if (screenText.contains("ok")) {
            performTap("ok", root)
        }
    }

    private fun performTap(text: String, root: AccessibilityNodeInfo) {
        isProcessing = true
        try {
            // Find by text
            val nodes = root.findAccessibilityNodeInfosByText(text)
            if (nodes.isNotEmpty()) {
                nodes[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
                Log.d(TAG, "Tapped: $text")
                return
            }

            // Find by content description
            val allNodes = root.findAccessibilityNodeInfosByViewId("android:id/text1")
            allNodes.forEach { node ->
                if (node.text?.toString()?.contains(text, true) == true) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Log.d(TAG, "Tapped by content: $text")
                    return
                }
            }
        } finally {
            isProcessing = false
        }
    }

    private fun inputText(text: String, root: AccessibilityNodeInfo) {
        isProcessing = true
        try {
            val editFields = root.findAccessibilityNodeInfosByViewId("android:id/edit")
            if (editFields.isNotEmpty()) {
                val args = Bundle()
                args.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    text
                )
                editFields[0].performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                Log.d(TAG, "Entered text: $text")

                // Press OK/Next button
                Thread.sleep(500)
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        } finally {
            isProcessing = false
        }
    }

    private fun shouldHandleEvent(event: AccessibilityEvent): Boolean {
        val packageName = event.packageName?.toString() ?: ""
        return packageName.contains("dialer") ||
                packageName.contains("phone") ||
                packageName.contains("com.android.incallui")
    }

    private fun getScreenText(event: AccessibilityEvent): String {
        return event.text.joinToString(" ").trim()
    }

    private fun resetState() {
        currentStep = 0
        isProcessing = false
        Log.d(TAG, "State reset for next transaction")
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted")
        notificationService.showErrorNotification("Service interrupted")
    }
}